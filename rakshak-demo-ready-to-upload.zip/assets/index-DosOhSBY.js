import{b as r}from"./index-EvPr0cWL.js";var a=r();export{a as r};
